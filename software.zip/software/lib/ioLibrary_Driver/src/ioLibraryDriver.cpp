extern "C" 
{
    #include "Ethernet/wizchip_conf.h"
    #include "Ethernet/W5500/w5500.h"
    #include "Ethernet/socket.h"
    #include "Internet/DHCP/dhcp.h"
    #include "Internet/DNS/dns.h"
}