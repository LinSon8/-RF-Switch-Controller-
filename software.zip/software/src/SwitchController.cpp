#include <SwitchController.h>

SwitchController::SwitchController() : currentState(0) {}